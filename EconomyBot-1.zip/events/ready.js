module.exports = (client) => {
    console.log(`${client.user.tag} is Do Not Disturb!`);
  client.user.setActivity("Rouge On Top");
};
