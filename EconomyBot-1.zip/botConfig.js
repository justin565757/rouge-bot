module.exports = {
    token: "ODE3MjcxODE3MTgwOTM4MjUw.YEHFsQ.6g0c7BeOp6N36ryUBmqBHmNL3ek",
    prefix: "-",
    admins: [
        "814641030212354098"
],
    debug: true,
    countChannel: "countChannelID"
};
